#!/bin/sh
python /home/pi/scripts/regDump.py > /home/pi/settings/defaults/current.set
